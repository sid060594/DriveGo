package com.example.siddharth.drivergo.constants;

/**
 * Created by Sid on 10/30/2018.
 */

public class Constant {

    public  static String transporter_id="";
    public  static String current_latitute="";
    public  static String current_longitute="";
    public  static String check="";



}
