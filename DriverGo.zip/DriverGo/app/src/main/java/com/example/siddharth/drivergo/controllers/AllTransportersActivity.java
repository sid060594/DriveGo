package com.example.siddharth.drivergo.controllers;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.example.siddharth.drivergo.R;

public class AllTransportersActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_transporters);

    }

}
